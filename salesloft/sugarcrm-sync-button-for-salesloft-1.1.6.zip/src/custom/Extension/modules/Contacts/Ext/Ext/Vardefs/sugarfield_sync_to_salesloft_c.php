<?php

$dictionary['Contact']['fields']['sync_to_salesloft_c']['labelValue']='sync to salesloft';
$dictionary['Contact']['fields']['sync_to_salesloft_c']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['sync_to_salesloft_c']['enforced']='';
$dictionary['Contact']['fields']['sync_to_salesloft_c']['dependency']='';

 ?>