<?php
//Insert our custom button definition into existing Record View Buttons array for Leads module before the sidebar toggle button
array_splice($viewdefs['Leads']['base']['view']['record']['buttons'], -3, 0, array(
    array(
        'name' => 'sync_button',
        'type' => 'button',
        'label' => 'Sync to SalesLoft',
        'css_class' => 'btn-link',
        //Set target object for Sidecar Event.
        //By default, button events are triggered on current Context but can optionally set target to 'view' or 'layout'
        //'target' => 'context'
        'events' => array(
            // custom Sidecar Event to trigger on click.  Event name can be anything you want.
            'click' => 'button:sync_button:click',
        )
    ),
));

//Add field to view
$viewdefs['Leads']['base']['view']['record']['panels'][1]['fields'][] = array(
    'name' => 'salesloft_record_c',
    'label' => 'LBL_SALESLOFT_RECORD',
);