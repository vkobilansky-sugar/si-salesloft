<?php
$manifest = array (
  'id' => 'sync-button-for-salesloft',
  'name' => 'Sync Button on the Record View',
  'description' => 'Adds buttons and custom fields for SalesLoft sync',
  'version' => '1.2.1',
  'author' => 'SugarCRM, Inc.',
  'is_uninstallable' => 'true',
  'published_date' => '2020-08-17 20:46:48',
  'type' => 'module',
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
    ),
    'regex_matches' => 
    array (
      0 => '(10|9|8|7)\\..*$',
    ),
  ),
  'acceptable_sugar_flavors' => 
  array (
    0 => 'PRO',
    1 => 'ENT',
    2 => 'ULT',
  ),
);
$installdefs = array (
  'beans' => 
  array (
  ),
  'id' => 'sync-button-for-salesloft',
  'platforms' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/Files/custom/Extension/application/Ext/Platforms/sugar-integrate.php',
    ),
  ),
  'post_execute' => 
  array (
    0 => 'scripts/cleanup.php',
  ),
  'language' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/Files/custom/Extension/modules/Contacts/Ext/Language/en_us.lang.ext.php',
      'to_module' => 'Contacts',
      'language' => 'en_us',
    ),
    1 => 
    array (
      'from' => '<basepath>/Files/custom/Extension/modules/Leads/Ext/Language/en_us.lang.ext.php',
      'to_module' => 'Leads',
      'language' => 'en_us',
    ),
  ),
  'custom_fields' => 
  array (
    0 => 
    array (
      'name' => 'sync_to_salesloft_c',
      'label' => 'LBL_SYNC_TO_SALESLOFT',
      'type' => 'integer',
      'max_size' => 1,
      'require_option' => 'optional',
      'required' => false,
      'default_value' => '0',
      'audited' => true,
      'importable' => true,
      'module' => 'Contacts',
    ),
    1 => 
    array (
      'name' => 'salesloft_record_c',
      'label' => 'LBL_SALESLOFT_RECORD',
      'type' => 'url',
      'max_size' => 255,
      'require_option' => 'optional',
      'default_value' => '',
      'required' => false,
      'audited' => true,
      'importable' => true,
      'module' => 'Contacts',
    ),
    2 => 
    array (
      'name' => 'sync_to_salesloft_c',
      'label' => 'LBL_SYNC_TO_SALESLOFT',
      'type' => 'integer',
      'max_size' => 1,
      'require_option' => 'optional',
      'default_value' => '0',
      'required' => false,
      'audited' => true,
      'importable' => true,
      'module' => 'Leads',
    ),
    3 => 
    array (
      'name' => 'salesloft_record_c',
      'label' => 'LBL_SALESLOFT_RECORD',
      'type' => 'url',
      'max_size' => 255,
      'require_option' => 'optional',
      'default_value' => '',
      'required' => false,
      'audited' => true,
      'importable' => true,
      'module' => 'Leads',
    ),
  ),
  'copy' => 
  array (
    0 => 
    array (
      'from' => '<basepath>/src/.DS_Store',
      'to' => '.DS_Store',
    ),
    1 => 
    array (
      'from' => '<basepath>/src/scripts/cleanup.php',
      'to' => 'scripts/cleanup.php',
    ),
    2 => 
    array (
      'from' => '<basepath>/src/Files/.DS_Store',
      'to' => 'Files/.DS_Store',
    ),
    3 => 
    array (
      'from' => '<basepath>/src/Files/Languages/Leads/en_us.lang.php',
      'to' => 'Files/Languages/Leads/en_us.lang.php',
    ),
    4 => 
    array (
      'from' => '<basepath>/src/Files/Languages/Contacts/en_us.lang.php',
      'to' => 'Files/Languages/Contacts/en_us.lang.php',
    ),
    5 => 
    array (
      'from' => '<basepath>/src/custom/.DS_Store',
      'to' => 'custom/.DS_Store',
    ),
    6 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/JSGroupings/addSyncButton.php',
      'to' => 'custom/Extension/application/Ext/JSGroupings/addSyncButton.php',
    ),
    7 => 
    array (
      'from' => '<basepath>/src/custom/Extension/application/Ext/Platforms/sugar-integrate.php',
      'to' => 'custom/Extension/application/Ext/Platforms/sugar-integrate.php',
    ),
    8 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/clients/base/views/record/sync_button.php',
      'to' => 'custom/Extension/modules/Leads/Ext/clients/base/views/record/sync_button.php',
    ),
    9 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Leads/Ext/Language/en_us.lang.ext.php',
      'to' => 'custom/Extension/modules/Leads/Ext/Language/en_us.lang.ext.php',
    ),
    10 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/clients/base/views/record/sync_button.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/clients/base/views/record/sync_button.php',
    ),
    11 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/Ext/Vardefs/sugarfield_sync_to_salesloft_c.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Ext/Vardefs/sugarfield_sync_to_salesloft_c.php',
    ),
    12 => 
    array (
      'from' => '<basepath>/src/custom/Extension/modules/Contacts/Ext/Language/en_us.lang.ext.php',
      'to' => 'custom/Extension/modules/Contacts/Ext/Language/en_us.lang.ext.php',
    ),
    13 => 
    array (
      'from' => '<basepath>/src/custom/modules/Leads/syncButton.js',
      'to' => 'custom/modules/Leads/syncButton.js',
    ),
    14 => 
    array (
      'from' => '<basepath>/src/custom/modules/Contacts/syncButton.js',
      'to' => 'custom/modules/Contacts/syncButton.js',
    ),
  ),
);
