<?php

$mod_strings['LBL_SYNC_TO_SALESLOFT'] = 'Sync to SalesLoft';
$mod_strings['LBL_SALESLOFT_RECORD'] = 'SalesLoft Record';