<?php

$platforms[] = 'sugar-integrate';