<?php
//Insert our custom button definition into existing Record View Buttons array for Contacts module before the sidebar toggle button
array_splice($viewdefs['Contacts']['base']['view']['record']['buttons'], -3, 0, array(
    array(
        'name' => 'sync_button',
        'type' => 'button',
        'label' => 'Sync to SalesLoft',
        'css_class' => 'btn-link',
        'id' => 'sync-button',
        'events' => array(
            'click' => 'button:sync_button:click',
        )
    ),
));

//Add field to view
$viewdefs['Contacts']['base']['view']['record']['panels'][1]['fields'][] = array(
    'name' => 'salesloft_record_c',
    'label' => 'LBL_SALESLOFT_RECORD',
);