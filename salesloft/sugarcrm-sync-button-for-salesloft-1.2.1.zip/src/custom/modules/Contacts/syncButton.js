(function(app){
    //Run callback when Sidecar metadata is fully initialized
    app.events.on('app:sync:complete', function(){
        //When a record layout is loaded...
        app.router.on('route:record', function(module){
       
            //AND the module is Contacts...
            if (module === 'Contacts') {
                
                //AND the 'button:sync_button:click' event occurs on the current Context
                app.controller.context.on('button:sync_button:click', function(model) {
                    $('a[name="sync_button"]').text('Sync Pending');
                    model.unset('portal_password');
                    model.set('sync_to_salesloft_c', '1'); 
                    model.save();
                });


                // app.controller.context.on('button:edit_button:click', function(model) {
                //     $('a[name="sync_button"]').hide();
                // });

                // app.controller.context.on('button:cancel_button:click', function(model) {
                //     $('a[name="sync_button"]').show();
                // });
            }
        });
    });
})(SUGAR.App);
