<?php

if (! defined('sugarEntry') || ! sugarEntry) die('Not A Valid Entry Point');
require_once("modules/Administration/QuickRepairAndRebuild.php");
$randc = new RepairAndClear();

//Rebuild extensions then clear include/javascript files
$randc->repairAndClearAll(array('rebuildExtensions', 'clearAdditionalCaches'),array(translate('LBL_ALL_MODULES')), false, true);